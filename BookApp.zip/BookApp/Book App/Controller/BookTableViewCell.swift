//
//  BookTableViewCell.swift
//  Book App
//
//  Created by Can Yıldırım on 1.02.24.
//

import UIKit

class BookTableViewCell: UITableViewCell {
    
    override func awakeFromNib() {
            super.awakeFromNib()
        
        }

    override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
        
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            
            self.imageView?.frame = CGRectMake(10,5,35,45)
            self.imageView?.contentMode = UIView.ContentMode.scaleAspectFill
            self.textLabel?.frame = CGRect(x: 70, y: 10, width: 300, height: 20)
            self.detailTextLabel?.frame = CGRect(x: 70, y: 30, width: 30, height: 20)

    }
}
